import React from 'react';

interface DroneGraphicProps {
  className?: string;
  altitude?: number;
  temperature?: number;
  isAscending?: boolean;
  reducedMotion?: boolean;
}

export const DroneGraphic: React.FC<DroneGraphicProps> = ({
  className = 'w-64 h-48',
  altitude = 175,
  temperature = 24.37,
  isAscending = false,
  reducedMotion = false,
}) => {
  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      {/* Background glow */}
      <div className="absolute w-48 h-48 rounded-full bg-cyan-500/10 blur-2xl pointer-events-none" />

      <svg
        viewBox="0 0 320 220"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`w-full h-full drop-shadow-[0_10px_25px_rgba(6,182,212,0.25)] ${
          reducedMotion ? '' : 'animate-float'
        }`}
      >
        <defs>
          <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="50%" stopColor="#0f172a" />
            <stop offset="100%" stopColor="#090d16" />
          </linearGradient>
          <linearGradient id="armGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#334155" />
            <stop offset="50%" stopColor="#475569" />
            <stop offset="100%" stopColor="#1e293b" />
          </linearGradient>
          <linearGradient id="cyanNeon" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#06b6d4" />
            <stop offset="100%" stopColor="#38bdf8" />
          </linearGradient>
        </defs>

        {/* Diagonal Arms */}
        {/* Left Arm */}
        <line x1="60" y1="65" x2="160" y2="115" stroke="url(#armGrad)" strokeWidth="9" strokeLinecap="round" />
        <line x1="60" y1="165" x2="160" y2="115" stroke="url(#armGrad)" strokeWidth="9" strokeLinecap="round" />
        {/* Right Arm */}
        <line x1="260" y1="65" x2="160" y2="115" stroke="url(#armGrad)" strokeWidth="9" strokeLinecap="round" />
        <line x1="260" y1="165" x2="160" y2="115" stroke="url(#armGrad)" strokeWidth="9" strokeLinecap="round" />

        {/* LED Tracer Lines along arms */}
        <line x1="75" y1="73" x2="145" y2="108" stroke="#06b6d4" strokeWidth="2" strokeDasharray="4 3" opacity="0.8" />
        <line x1="75" y1="157" x2="145" y2="122" stroke="#06b6d4" strokeWidth="2" strokeDasharray="4 3" opacity="0.8" />
        <line x1="245" y1="73" x2="175" y2="108" stroke="#06b6d4" strokeWidth="2" strokeDasharray="4 3" opacity="0.8" />
        <line x1="245" y1="157" x2="175" y2="122" stroke="#06b6d4" strokeWidth="2" strokeDasharray="4 3" opacity="0.8" />

        {/* Motor Pods */}
        {/* Top-Left */}
        <circle cx="60" cy="65" r="14" fill="#0f172a" stroke="#06b6d4" strokeWidth="2.5" />
        <circle cx="60" cy="65" r="5" fill="#38bdf8" />
        <ellipse
          cx="60"
          cy="65"
          rx="38"
          ry="9"
          fill="none"
          stroke="#38bdf8"
          strokeWidth="1.5"
          opacity="0.6"
          strokeDasharray="6 3"
          className={reducedMotion ? '' : 'origin-[60px_65px] animate-spin'}
          style={{ animationDuration: '0.4s' }}
        />

        {/* Top-Right */}
        <circle cx="260" cy="65" r="14" fill="#0f172a" stroke="#06b6d4" strokeWidth="2.5" />
        <circle cx="260" cy="65" r="5" fill="#38bdf8" />
        <ellipse
          cx="260"
          cy="65"
          rx="38"
          ry="9"
          fill="none"
          stroke="#38bdf8"
          strokeWidth="1.5"
          opacity="0.6"
          strokeDasharray="6 3"
          className={reducedMotion ? '' : 'origin-[260px_65px] animate-spin'}
          style={{ animationDuration: '0.4s' }}
        />

        {/* Bottom-Left */}
        <circle cx="60" cy="165" r="14" fill="#0f172a" stroke="#06b6d4" strokeWidth="2.5" />
        <circle cx="60" cy="165" r="5" fill="#38bdf8" />
        <ellipse
          cx="60"
          cy="165"
          rx="38"
          ry="9"
          fill="none"
          stroke="#38bdf8"
          strokeWidth="1.5"
          opacity="0.6"
          strokeDasharray="6 3"
          className={reducedMotion ? '' : 'origin-[60px_165px] animate-spin'}
          style={{ animationDuration: '0.4s' }}
        />

        {/* Bottom-Right */}
        <circle cx="260" cy="165" r="14" fill="#0f172a" stroke="#06b6d4" strokeWidth="2.5" />
        <circle cx="260" cy="165" r="5" fill="#38bdf8" />
        <ellipse
          cx="260"
          cy="165"
          rx="38"
          ry="9"
          fill="none"
          stroke="#38bdf8"
          strokeWidth="1.5"
          opacity="0.6"
          strokeDasharray="6 3"
          className={reducedMotion ? '' : 'origin-[260px_165px] animate-spin'}
          style={{ animationDuration: '0.4s' }}
        />

        {/* Central Carbon Fuselage */}
        <path
          d="M 120 100 L 160 80 L 200 100 L 205 130 L 160 150 L 115 130 Z"
          fill="url(#bodyGrad)"
          stroke="#38bdf8"
          strokeWidth="2.5"
        />

        {/* Fuselage Core Sensor Window */}
        <ellipse cx="160" cy="115" rx="18" ry="14" fill="#090d16" stroke="#06b6d4" strokeWidth="2" />
        <circle cx="160" cy="115" r="6" fill="#06b6d4" className="animate-pulse" />

        {/* Forward Meteorological Probe Assembly */}
        <path d="M 160 80 L 160 30" stroke="#f59e0b" strokeWidth="3.5" strokeLinecap="round" />
        {/* Sensor Tip Thermistor */}
        <circle cx="160" cy="26" r="6" fill="#f59e0b" stroke="#fef08a" strokeWidth="1.5" className="animate-pulse" />
        {/* Sensor Sensing Waves */}
        <path d="M 150 18 A 12 12 0 0 1 170 18" stroke="#f59e0b" strokeWidth="1.5" strokeLinecap="round" fill="none" opacity="0.8" />
        <path d="M 144 12 A 20 20 0 0 1 176 12" stroke="#f59e0b" strokeWidth="1.2" strokeLinecap="round" fill="none" opacity="0.5" />

        {/* Telemetry Antenna */}
        <line x1="180" y1="90" x2="195" y2="70" stroke="#94a3b8" strokeWidth="2" />
        <circle cx="197" cy="68" r="3" fill="#38bdf8" />

        {/* Navigation Strobe lights */}
        <circle cx="45" cy="65" r="3" fill="#ef4444" />
        <circle cx="275" cy="65" r="3" fill="#22c55e" />
      </svg>

      {/* Floating Telemetry HUD Tag */}
      <div className="absolute -bottom-2 bg-navy-900/90 backdrop-blur-md border border-cyan-500/40 rounded-lg px-3 py-1 text-center shadow-lg pointer-events-none">
        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span className="text-slate-300">ALT:</span>
          <span className="text-cyan-300 font-bold">{altitude} m</span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-300">TEMP:</span>
          <span className="text-amber-400 font-bold">{temperature.toFixed(2)} °C</span>
        </div>
      </div>
    </div>
  );
};
