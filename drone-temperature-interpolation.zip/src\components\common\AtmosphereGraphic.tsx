import React from 'react';
import { DataPoint } from '../../types/index.ts';

interface AtmosphereGraphicProps {
  currentAltitude?: number;
  points?: DataPoint[];
  targetAltitude?: number;
  onSelectAltitude?: (alt: number) => void;
  className?: string;
}

export const AtmosphereGraphic: React.FC<AtmosphereGraphicProps> = ({
  currentAltitude = 175,
  points = [
    { id: 'p0', x: 0, y: 28.5 },
    { id: 'p1', x: 100, y: 26.1 },
    { id: 'p2', x: 200, y: 23.8 },
    { id: 'p3', x: 300, y: 21.6 },
    { id: 'p4', x: 400, y: 19.5 },
  ],
  targetAltitude = 175,
  onSelectAltitude,
  className = '',
}) => {
  const maxAlt = 400;

  return (
    <div className={`relative bg-gradient-to-t from-slate-900 via-navy-900 to-navy-950 border border-slate-800 rounded-2xl p-5 overflow-hidden ${className}`}>
      {/* Background Altitude Atmospheric Heatmap Gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-amber-500/10 via-cyan-500/10 to-blue-600/10 pointer-events-none" />

      {/* Grid lines */}
      <div className="relative h-72 flex justify-between">
        {/* Left Vertical Altitude Axis */}
        <div className="w-20 flex flex-col justify-between py-2 text-xs font-mono text-slate-400 border-r border-slate-700/60 pr-3">
          {[400, 300, 200, 100, 0].map((alt) => (
            <div key={alt} className="flex items-center justify-between">
              <span className="font-semibold text-slate-300">{alt} m</span>
              <div className="w-2 h-0.5 bg-cyan-500/60" />
            </div>
          ))}
        </div>

        {/* Center Graphic Visualization Column */}
        <div className="flex-1 relative mx-6 flex flex-col justify-between py-2">
          {/* Horizontal grid bands */}
          {[400, 300, 200, 100, 0].map((alt) => {
            const pt = points.find(p => p.x === alt);
            return (
              <div key={alt} className="relative flex items-center group">
                <div className="w-full border-t border-dashed border-slate-700/60" />
                {pt && (
                  <button
                    onClick={() => onSelectAltitude?.(alt)}
                    className="absolute right-0 translate-x-2 -translate-y-1/2 flex items-center gap-2 bg-slate-800/80 hover:bg-cyan-950/80 border border-cyan-500/40 rounded-full px-2.5 py-1 text-xs font-mono transition-all duration-200"
                  >
                    <span className="w-2 h-2 rounded-full bg-cyan-400 group-hover:scale-125 transition-transform" />
                    <span className="text-cyan-300 font-medium">{pt.y.toFixed(1)} °C</span>
                    <span className="text-slate-500 text-[10px]">Sampled</span>
                  </button>
                )}
              </div>
            );
          })}

          {/* Target Altitude Highlight Band */}
          {targetAltitude !== undefined && (
            <div
              className="absolute left-0 right-0 border-t-2 border-amber-400 flex items-center justify-between transition-all duration-300 pointer-events-none z-10"
              style={{ bottom: `${(targetAltitude / maxAlt) * 100}%` }}
            >
              <div className="bg-amber-500/20 text-amber-300 text-[11px] font-mono px-2 py-0.5 rounded -translate-y-1/2 border border-amber-500/60 shadow-lg flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                Target: {targetAltitude} m (Interpolated)
              </div>
              <div className="h-0.5 w-16 bg-gradient-to-r from-amber-400 to-transparent" />
            </div>
          )}

          {/* Drone Position Marker */}
          <div
            className="absolute left-1/3 -translate-x-1/2 -translate-y-1/2 transition-all duration-500 pointer-events-none z-20 flex items-center gap-3"
            style={{ bottom: `${(currentAltitude / maxAlt) * 100}%` }}
          >
            <div className="w-10 h-10 rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.6)] animate-pulse">
              <span className="text-xs">🚁</span>
            </div>
            <div className="bg-navy-950/90 border border-cyan-400/80 rounded px-2 py-0.5 text-[10px] font-mono text-cyan-200 whitespace-nowrap shadow-md">
              Drone Ascent: {currentAltitude} m
            </div>
          </div>
        </div>

        {/* Right Legend Column */}
        <div className="w-28 flex flex-col justify-between py-2 text-[11px] text-slate-400 pl-3 border-l border-slate-700/60">
          <div>
            <div className="text-cyan-400 font-semibold mb-0.5">Troposphere</div>
            <div className="text-[10px] text-slate-500">Normal Lapse</div>
          </div>
          <div className="bg-slate-800/60 p-2 rounded border border-slate-700/50">
            <div className="text-amber-400 font-medium text-[10px]">Lapse Rate:</div>
            <div className="text-slate-300 font-mono text-[10px]">~ -2.25 °C / 100m</div>
          </div>
          <div>
            <div className="text-slate-400 font-semibold mb-0.5">Surface (0m)</div>
            <div className="text-[10px] text-slate-500">28.5 °C Ground</div>
          </div>
        </div>
      </div>
    </div>
  );
};
